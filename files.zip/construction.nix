{
  _,
  names,
  ...
}: let
  meta = let
    doc = ''
      Module Evaluation and System Generation

      Provides the orchestration layer for turning discovered hosts, resolved
      flake inputs, generated package sets, and assembled module lists into
      fully evaluated system configurations.

      This file is responsible for three major tasks:

      1. Evaluating NixOS/Darwin host systems via `evalModules` (`mkSystems`).
      2. Evaluating standalone Home Manager hosts via
         `home-manager.lib.homeManagerConfiguration` (`mkHomes`).
      3. Composing both into the final host-derived flake outputs (`mkHosts`),
         and generating per-system flake-style output matrices (`mkFlake`).

      ## Host routing

      Every host in `schema.hosts` declares a `class` (default `"nixos"`).
      `class` decides which builder owns the host and, in turn, which
      top-level flake output it lands under:

        class            | builder     | output key
        -----------------|-------------|----------------------
        "nixos" (default)| mkSystems   | nixosConfigurations
        "darwin"         | mkSystems   | nixosConfigurations *
        "home-manager"   | mkHomes     | homeConfigurations

      * Darwin hosts still flow through `mkSystems`/`evalModules` today - see
        the `class == "darwin"` branch there for the `system.build.toplevel`
        exposure. A dedicated `darwinConfigurations` output is a natural
        follow-up once `nix-darwin`'s own top-level builder is wired in the
        same way `mkHomes` wires `homeManagerConfiguration`.

      `mkSystems` and `mkHomes` each filter `schema.hosts` down to the hosts
      they own, so a host only ever appears under exactly one output. Neither
      function needs to know the other exists - `mkHosts` is the only place
      that composes them, and `flake.nix` never sees the split at all.
    '';
    functions = {
      inherit
        mkSystems
        mkHomes
        mkHosts
        mkFlake
        mkCore
        mkHome
        mkTree
        mkConfig
        mkContext
        ;
    };
    exports = {
      local = functions;
      store = functions;
    };
  in {
    inherit doc exports functions;
  };

  inherit (_.attrsets.access) attrNames getAttrFromPath;
  inherit (_.attrsets.construction) genAttrs;
  inherit (_.attrsets.transformation) filterAttrs mapAttrs setAttrByPath;
  inherit (_.filesystem.tree) mkTree;
  inherit (_.hardware.system) getSystems;
  inherit (_.lists.access) head;
  inherit (_.lists.construction) optionals;
  inherit (_.modules.evaluation) evalModules extend;
  inherit (_.modules.construction) mkIf mkMerge;
  inherit (_.modules.home.users) mkUsers;
  inherit (_.options.construction) mkOption;
  inherit (_.sources.modules) mkModules;
  inherit (_.sources.packages) mkPackages;
  inherit (_.sources.packages) mkAll;
  inherit (_.types.combinators) attrsOf submodule;
  inherit (_.types.primitives) anything;

  #~@ Hosts whose `class` routes them to mkHomes instead of mkSystems.
  isHomeManagerHost = host: (host.class or "nixos") == "home-manager";

  /**
  Evaluate every NixOS/Darwin host from the discovered schema into a
  fully-keyed `nixosConfigurations` output block.

  Builds the repository tree, resolves flake inputs, generates package and
  module sets for each NixOS/Darwin host, and evaluates the final module
  graph through `lib.modules.evalModules`. Hosts with `class ==
  "home-manager"` are skipped entirely - see `mkHomes`.

  For Darwin hosts, this also exposes the built system derivation under
  `system` for easier downstream consumption.

  # Args:
    flake: The evaluated flake (name/path/home derived from it).
    inputs: Canonically resolved flake inputs.
    paths: The resolved path tree.
    libraries: The assembled internal library set.
    names: Canonical name registry (flake/lib/top/...).
    tree: Repository tree metadata.
    schema: Discovered host/user schema; `schema.hosts` is consumed here.
    extraArgs: Extra arguments merged into `specialArgs`.

  # Returns:
    `{ nixosConfigurations = { <hostName> = <evaluated config>; ... }; }`
  */
  mkSystems = {
    flake,
    inputs,
    paths,
    libraries,
    names,
    tree,
    stems,
    schema,
    extraArgs ? {},
    ...
  }: {
    nixosConfigurations =
      mapAttrs (
        _: host: let
          class = host.class or "nixos";
          #> Per-host tree: extends the global `stems` with this host's own
          #> `paths.*` entries as a new `host` group (Victus's `paths.src`,
          #> TheOracle's `paths.flake`, etc.), rather than reusing a single
          #> shared `tree` computed once from whichever host happened to be
          #> `$HOSTNAME` at bootstrap. Global groups (`api`, `lib`, `mod`,
          #> ...) are unaffected - only `host.*` is added.
          tree' = mkTree {
            stems = stems // {host = host.paths or {};};
            roots = {
              user = paths.home.local;
              xdg = paths.home.local;
              host = flake.path;
            };
          };

          specialArgs =
            {
              inherit
                host
                class
                inputs
                flake
                names
                paths
                ;
              inherit (names) top;
              "${names.lib}" = libraries.${names.lib};
              tree = tree';
            }
            // extraArgs;

          flakeArgs = let
            packages = mkPackages {inherit host inputs;};
            modules = mkModules {inherit class inputs;};
          in {
            inherit inputs packages modules;
          };

          moduleArgs = let
            fromInputs = flakeArgs.modules;
            fromHost = mkCore {
              inherit host specialArgs;
              inherit (flakeArgs) modules inputs;
              inherit (flakeArgs.packages) nixpkgs;
              tree = tree';
            };
            fromEval = evalModules {
              specialArgs =
                specialArgs
                // {
                  inherit (fromInputs.all) modulesPath baseModules;
                  modules =
                    fromInputs
                    // {
                      host = fromHost;
                    };
                };
              modules =
                fromInputs.base
                ++ fromInputs.core
                ++ fromHost
                ++ (host.imports or [])
                ++ [tree'.store.mod.core]
                ++ [{config._module.args = specialArgs;}];
            };
          in {
            inherit fromInputs fromHost fromEval;
          };
        in
          if class == "darwin"
          then moduleArgs.fromEval // {system = moduleArgs.fromEval.config.system.build.toplevel;}
          else moduleArgs.fromEval
      )
      (filterAttrs (_: host: !(isHomeManagerHost host)) schema.hosts);
  };

  /**
  Evaluate every standalone Home Manager host from the discovered schema
  into a fully-keyed `homeConfigurations` output block.

  Unlike `mkSystems`, this never touches `evalModules` or the NixOS module
  list (`nixos/modules/module-list.nix`) - it goes straight through
  `home-manager.lib.homeManagerConfiguration`, which is the correct entry
  point for hosts where Nix is a package manager layered onto a foreign OS
  (e.g. Ubuntu + Nix on a cloud instance) rather than the OS itself. Only
  hosts with `class == "home-manager"` are considered; everything else is
  left for `mkSystems`.

  Each host's per-user home-manager module is built via `mkUsers { ...;
  standalone = true; }`, the same builder `mkSystems`/`mkHome` use for
  NixOS-embedded users - `standalone = true` swaps out the two facts that
  differ outside a NixOS eval (`home.stateVersion` has no `nixosConfig` to
  borrow from, and `home.username`/`home.homeDirectory` have no NixOS
  `users.users.<name>` entry to infer from), while every other concern
  (imports, style, keyboard, locale, session paths) is identical.

  Currently assumes exactly one interactive user per home-manager-class
  host (the first key of `mkUsers`' result). Hosts that legitimately need
  more than one standalone user will need this extended to emit one
  `homeConfigurations.<host>-<user>` entry per user instead of one per host.

  # Args:
    Same as `mkSystems`.

  # Returns:
    `{ homeConfigurations = { <hostName> = <homeManagerConfiguration>; ... }; }`
  */
  mkHomes = {
    flake,
    inputs,
    paths,
    libraries,
    names,
    tree,
    stems,
    schema,
    extraArgs ? {},
    ...
  }: {
    homeConfigurations =
      mapAttrs (
        hostName: host: let
          #> See mkSystems' identical tree' construction for rationale.
          tree' = mkTree {
            stems = stems // {host = host.paths or {};};
            roots = {
              user = paths.home.local;
              xdg = paths.home.local;
              host = flake.path;
            };
          };

          specialArgs =
            {
              inherit host inputs names paths;
              inherit (names) top;
              "${names.lib}" = libraries.${names.lib};
              tree = tree';
            }
            // extraArgs;

          packages = mkPackages {inherit host inputs;};
          modules = mkModules {
            class = "home-manager";
            inherit inputs;
          };

          hmUsers = mkUsers {
            inherit host inputs;
            modules = modules.home;
            tree = tree';
            standalone = true;
          };

          userNames = attrNames hmUsers;
          username =
            assert userNames != [] || throw "mkHomes: host '${hostName}' (class = \"home-manager\") has no interactive users to build a homeConfiguration for";
            head userNames;
        in
          inputs.home-manager.lib.homeManagerConfiguration {
            pkgs = packages.pkgs;
            extraSpecialArgs = specialArgs;
            modules = [hmUsers.${username}];
          }
      )
      (filterAttrs (_: isHomeManagerHost) schema.hosts);
  };

  /**
  Compose every host-derived flake output into a single pre-keyed attrset.

  This is the one call `mkFlake` makes to get every host-class output at
  once. It does no evaluation of its own - it only calls `mkSystems` and
  `mkHomes` and merges their already-
  keyed results (`nixosConfigurations`, `homeConfigurations`). Adding a new
  host class later (e.g. a dedicated `darwinConfigurations` builder) means
  adding one more function here, not touching `flake.nix`.

  # Args:
    Same as `mkSystems`/`mkHomes` - passed straight through to both.

  # Returns:
    `{ nixosConfigurations = {...}; homeConfigurations = {...}; }`
  */
  mkHosts = args:
    (mkSystems args)
    // (mkHomes args);

  /**
  Build the host-specific core module list used during system evaluation.

  Produces the base module stack for a host by combining low-level hardware,
  networking, environment, services, programs, users, and home-manager glue.
  The result is returned as a module list suitable for `evalModules`.

  # Args:
    host: The enriched host definition.
    nixpkgs: The resolved nixpkgs source/configuration attrset.
    inputs: Canonically resolved flake inputs.
    modules: Resolved input-provided module sets.
    specialArgs: Extra arguments forwarded into module evaluation.

  # Returns:
    A list of modules for the target host, including any host-local imports.
  */
  mkCore = {
    host,
    nixpkgs,
    inputs,
    modules,
    specialArgs,
    tree,
  }: [
    {
      nixpkgs = {
        flake.source = nixpkgs.outPath;
        config.allowUnfree = host.packages.allowUnfree or true;
      };
    }
    (mkHome {
      inherit
        host
        specialArgs
        tree
        inputs
        ;
      modules = modules.home;
    })
  ];

  /**
  Produce the complete Home Manager option block for the current host, to be
  nested under `home-manager.users.<name>` inside a NixOS/Darwin eval.

  Configures Home Manager to reuse the system package set, forward shared
  special arguments, and generate per-user configurations through the
  home user builder. This is the NixOS-embedded counterpart to `mkHomes`
  above - `mkHomes` builds standalone `homeConfigurations` entries with no
  parent NixOS eval at all, while this builds the `home-manager = {...}`
  fragment consumed by `mkCore`/`mkSystems`.

  # Args:
    host: The current host definition.
    specialArgs: Arguments forwarded into Home Manager modules.
    inputs: Canonically resolved flake inputs.
    modules: Resolved Home Manager module set.
    tree: Repository tree metadata used by downstream user builders.

  # Returns:
    A module fragment defining the `home-manager` configuration block.
  */
  mkHome = {
    host,
    specialArgs,
    inputs,
    modules,
    tree,
  }: {
    home-manager = {
      backupFileExtension = "backup";
      overwriteBackup = true;
      useGlobalPkgs = true;
      useUserPackages = true;
      extraSpecialArgs =
        specialArgs
        // {
          lib = extend (
            _self: _super: {
              hm = inputs.home-manager.lib.hm or {};
            }
          );
        };
      users = mkUsers {
        inherit
          inputs
          modules
          host
          tree
          ;
      };
    };
  };

  /**
  The single entry point `flake.nix` calls. Takes the raw `flake` (`self`)
  and the already-bootstrapped `src` (the result of `import ./. {inherit
  flake lib;}`), and owns everything downstream: assembling `args`, the
  `lib`/`templates` outputs, every host-derived output (via `mkHosts`), and
  the per-system output matrix (`packages.<system>.*`, `devShells.<system>.*`,
  etc.) driven by `fn`.

  This intentionally makes `mkFlake` couple to `dotDots`'s specific `args`/
  `flake'` shape rather than staying a generic per-system-fanout utility -
  that coupling is the whole point: it's what lets `flake.nix` shrink to
  wiring `{flake, src}` in and nothing else. A repo wanting a portable,
  repo-agnostic per-system fanout should reach for the transpose logic
  inlined below directly, not this function.

  ## `args` assembly

  Replicates the two-pass fixed-point `flake.nix` used to build inline:
  `mkAll {inherit flake;}` is merged over `src` to get a first-pass `args`
  (enough to read `names`/`paths` off it), then `flake` is re-derived with
  `name`/`path`/`home` attached from that first pass, and `args` is rebuilt
  a second time with the enriched `flake` folded back in. Downstream
  consumers (host builders, `mkHosts`, module `specialArgs`) read
  `flake.name`/`flake.path`/`flake.home`, so this fixed-point has to survive
  the move into `mkFlake` unchanged.

  TODO: once this is confirmed working end-to-end, revisit whether the
  two-pass fixed-point is still load-bearing or was circumstantial plumbing
  that can simplify now that it's no longer sitting directly in `flake.nix`.

  ## `lib` output

  `nix flake check` warns on unrecognized top-level output names; `args`
  itself isn't a recognized name, so the full `args` attrset is exposed
  under the accepted alias `lib` instead. This is not a curated "just the
  library" export - it is `args`, unchanged, under a name the checker
  accepts.

  ## `tree`

  `src.tree` is the plain, unextended tree - `templates` and `fn` both only
  need static store locations (`tree.kit.nix.store`, `tree.mod.global.store`),
  not the per-host `local` extension `mkSystems`/`mkHomes` each compute via
  `tree // {local = tree.mkLocal flake.path;}` for their own host-scoped
  needs. `mkFlake` never builds that extension itself; it flows through to
  `mkHosts` via `args` and is expected to remain host-scoped there.

  # Args:
    flake: The evaluated flake (`self`), before `dotDots`-specific enrichment.
    src: The bootstrapped source tree (`import ./. {inherit flake lib;}`),
      providing `lix`, `tree`, and everything `mkAll`/`mkHosts` need.
    nixpkgs: Optional nixpkgs input, forwarded to `getSystems`.
    legacyPackages: Optional pre-evaluated legacy package attrset.
    system: Preferred system to use for deriving per-system output names.

  # Returns:
    The complete flake outputs attrset: `lib`, `templates`,
    `nixosConfigurations`, `homeConfigurations`, and every per-system output
    group `fn` produces (`packages.<system>.*`, `devShells.<system>.*`, ...).
  */
  mkFlake = {
    flake,
    src,
    nixpkgs ? {},
    legacyPackages ? {},
    system ? null,
  }: let
    inherit (src) lix tree;
    inherit (lix.sources.packages) mkAll;
    inherit (lix.modules.construction) mkHosts;

    #> First pass: enough of `args` to read `names`/`paths` for enrichment.
    args0 = src // (mkAll {inherit flake;});

    #> `flake` enriched with the name/path/home fields host builders and
    #> module specialArgs expect at `flake.name`/`flake.path`/`flake.home`.
    flake' =
      args0
      // (with args0; {
        args = args0;
        name = names.flake;
        path = paths.flake.store;
        home = paths.flake.local;
      });

    #> Second pass: `args` rebuilt with the enriched `flake` folded back in.
    args = flake'.args // {flake = flake';};

    hosts = mkHosts args;

    fn = {
      system,
      pkgs,
    }:
      import tree.mod.global.store (args // {inherit pkgs system;});

    systems = getSystems {
      inherit
        flake
        nixpkgs
        legacyPackages
        system
        ;
      hosts = args.schema.hosts or {};
    };
    inherit (systems) pkgsFor derived all;

    perSystem = (genAttrs all) (
      sys:
        fn {
          system = sys;
          pkgs = pkgsFor sys;
        }
    );

    perSystemNames = attrNames (fn {
      system = derived;
      pkgs = pkgsFor derived;
    });
  in
    {
      lib = args;
      templates = import tree.kit.nix.store;
    }
    // hosts
    // genAttrs perSystemNames (name: mapAttrs (_: outputs: outputs.${name}) perSystem);

  mkConfig = {
    predicate ? null,
    outputs,
    options ? {},
    context,
  }: let
    inherit (context) path cfg top;
    condition =
      if predicate != null
      then predicate
      else cfg.enable or true;
    resolved = mkIf condition outputs;
  in {
    options = setAttrByPath path {
      explicit = options;
      implicit = mkOption {
        type = submodule {freeformType = attrsOf anything;};
        default = {};
      };
    };
    config = mkMerge [
      resolved
      {${top}.outputs = resolved;}
      (setAttrByPath (path ++ ["implicit"]) resolved)
    ];
  };

  mkContext = {
    config,
    top ? names.top,
    dom,
    sub ? null,
    mod,
    kind ?
      if sub == "core"
      then dom
      else null,
    name ? mod,
  }: let
    path = mkPath {
      inherit
        top
        dom
        sub
        mod
        ;
    };
  in
    {
      inherit
        config
        top
        dom
        sub
        mod
        path
        kind
        name
        ;
    }
    // {
      cfg = (getAttrFromPath path config).explicit;
    };

  mkPath = {
    top,
    dom,
    sub,
    mod,
  }:
    [
      top
      "resolved"
      dom
    ]
    ++ (optionals (sub != null) [sub])
    ++ [mod];
in
  meta.exports.local
  // {
    __docs = meta.doc;
    __rootAliases = meta.exports.store;
  }
