{_, ...}: let
  inherit (_.modules.core.users) homeUsers;
  inherit (_.modules.home.control) mkKeyboard;
  inherit (_.modules.home.paths) mkSessionPaths;
  inherit (_.modules.home.programs) mkApps;
  inherit (_.modules.home.style) mkStyle;
  inherit (_.schema._) mkUI mkLocale mkApplications;
  inherit (_.attrsets.construction) optionalAttrs;
  inherit (_.attrsets.transformation) mapAttrs;
  inherit (_.lists.construction) optionals;

  __exports = {
    internal = {inherit mkUsers;};
    external = {
      mkHomeUsers = mkUsers;
    };
  };

  /**
  Build the attrset passed directly to `home-manager.users` (NixOS-embedded
  mode), or, when `standalone = true`, the per-user module list handed
  straight to `home-manager.lib.homeManagerConfiguration` (see `mkHomes` in
  `Libraries/nix/modules/construction.nix`).

  Every concern here - style, keyboard, locale, session paths, and the
  `imports` list of home-manager modules pulled in from flake inputs - is
  identical between the two modes and is not branched on `standalone`.
  Only two facts genuinely differ between a NixOS-embedded user and a
  standalone one, and those are the only places `standalone` is consulted:

  1. `home.stateVersion` - inside a NixOS eval this is borrowed from the
     parent system's `nixosConfig.system.stateVersion` (the special-arg
     `home-manager.nixosModules.home-manager` injects into each user
     submodule). Standalone home-manager has no parent NixOS config to
     borrow from, so it falls back to `host.stateVersion`.

  2. `home.username` / `home.homeDirectory` - inside a NixOS eval these are
     inferred from the matching `users.users.<name>` entry created by
     `Libraries/nix/modules/core/users.nix`'s `mkUsers` (unrelated function,
     same name, different module - core-level system users vs. this
     home-level per-user module builder). Standalone home-manager has no
     such entry to infer from, so both must be set explicitly.

  # Type
  ```
  mkUsers :: {
    host :: AttrSet,
    inputs :: AttrSet,
    modules :: AttrSet,
    tree :: AttrSet,
    standalone :: bool ? false,
  } -> AttrSet
  ```
  */
  mkUsers = {
    host,
    inputs,
    modules,
    tree,
    standalone ? false,
  }:
    mapAttrs (
      name: spec: {
        config,
        pkgs,
        ...
      } @ hmArgs: let
        nixosConfig = hmArgs.nixosConfig or null;
        user = spec // {inherit name;};
        enrichedInterface = mkUI {inherit host user;};
        inputsForHome = mkApps {inherit user inputs modules;};
        derivedPaths = mkSessionPaths {
          inherit
            config
            host
            user
            pkgs
            tree
            ;
        };

        #> Only used by the standalone branch below. mkSessionPaths derives
        #> `home` from `config.home.homeDirectory`, which is circular when
        #> that option hasn't been set yet (exactly the case we're in here) -
        #> so standalone mode sidesteps derivedPaths.home entirely and uses
        #> the conventional Linux path instead.
        standaloneHome = "/home/${name}";
      in {
        _module.args = {
          style = mkStyle {inherit host user;};
          user = user // {interface = enrichedInterface;};
          apps = mkApplications {inherit host user;};
          keyboard = mkKeyboard {inherit host user;};
          locale = mkLocale {inherit host user;};
          paths = derivedPaths;
          inherit inputs inputsForHome;
        };

        home =
          {
            stateVersion =
              if standalone
              then (host.stateVersion or "26.05")
              else nixosConfig.system.stateVersion;
          }
          // optionalAttrs standalone {
            username = name;
            homeDirectory = standaloneHome;
          };

        imports = let
          hmi = inputsForHome;
        in
          [tree.store.mod.home]
          ++ optionals (hmi ? caelestia.module) [hmi.caelestia.module]
          ++ optionals (hmi ? catppuccin.module) [hmi.catppuccin.module]
          ++ optionals (hmi ? dms-shell.module) [hmi.dms-shell.module]
          ++ optionals (hmi ? dms-plugin-registry.module) [hmi.dms-plugin-registry.module]
          ++ optionals (hmi ? noctalia-shell.module) [hmi.noctalia-shell.module]
          ++ optionals (hmi ? nvf.module) [hmi.nvf.module]
          ++ optionals (hmi ? plasma.module) [hmi.plasma.module]
          ++ optionals (hmi ? zen-browser.module) [hmi.zen-browser.module]
          ++ (user.imports or []);
      }
    ) (homeUsers host);
in
  __exports.internal // {__rootAliases = __exports.external;}
