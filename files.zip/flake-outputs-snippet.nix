  outputs = inputs @ {self, ...}: let
    flake = self;
    inherit (inputs.nixPackages) lib legacyPackages;
    src = import ./. {inherit flake lib;};
    inherit (src.lix.modules.construction) mkFlake;
  in
    mkFlake {inherit flake src legacyPackages;};
